import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import loginRoute from './login.js';

const app = express();
const PORT = 5050;

// IMPORTANT: CORS must allow credentials and specify exact origin
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());
app.use(cookieParser());

app.use('/api', loginRoute);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});