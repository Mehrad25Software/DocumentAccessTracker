import express from 'express';
const router = express.Router();

const USER = {
    "admin": {
        password: "Adem_967",
        role: "Adem"
    }
};

// Login endpoint
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    if (!USER[username] || USER[username].password !== password) {
        return res.status(401).json({ message: "You do not have access to this page" });
    }
    
    res.cookie("token", "hardcoded-auth-token", {
        httpOnly: true,
        sameSite: "Lax",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        path: "/"
    });
    
    return res.status(200).json({ 
        message: "Login successful", 
        role: USER[username].role 
    });
});

// Check authentication endpoint
router.get('/check-auth', (req, res) => {
    const token = req.cookies.token;
    
    if (token === "hardcoded-auth-token") {
        return res.status(200).json({ 
            authenticated: true, 
            role: "Adem" 
        });
    }
    
    return res.status(401).json({ authenticated: false });
});

// Logout endpoint
router.post('/logout', (req, res) => {
    res.clearCookie("token");
    return res.status(200).json({ message: "Logged out successfully" });
});

export default router;