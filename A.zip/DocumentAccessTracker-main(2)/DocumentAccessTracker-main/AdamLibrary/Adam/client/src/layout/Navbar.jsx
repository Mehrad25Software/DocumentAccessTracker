import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { useState, useEffect, useRef } from "react";

const Navbar = ({ isAuthenticated, setIsAuthenticated }) => {
  const navigate = useNavigate();
  const audioRef = useRef(null);
  const [isMuted, setIsMuted] = useState(false);

  // Start playing audio when component mounts
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.play().catch(error => {
        console.log("Audio autoplay failed:", error);
      });
    }
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:5050/api/logout", {}, {
        withCredentials: true
      });
      setIsAuthenticated(false);
      alert("Logged out successfully!");
      navigate("/");
    } catch (error) {
      console.error("Logout error:", error);
      alert("Error logging out");
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const renderNavbarContent = () => {
    if (isAuthenticated) {
      return (
        <>
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/" style={{ color: "rgb(247, 215, 113)", fontWeight: "bold" }}>
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link active" to="/Adam-dashboard" style={{ color: "rgb(247, 215, 113)", fontWeight: "bold" }}>
                Dashboard
              </Link>
            </li>
          </ul>
          
          <button 
            className="btn btn-outline-light btn-sm me-2"
            onClick={toggleMute}
          >
            {isMuted ? "🔇" : "🔊"}
          </button>
          
          <button 
            className="btn btn-outline-light btn-sm"
            onClick={handleLogout}
          >
            Logout
          </button>
        </>
      );
    } else {
      return (
        <>
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to="/" style={{ color: "rgb(247, 215, 113)", fontWeight: "bold" }}>
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link active" to="/Login" style={{ color: "rgb(247, 215, 113)", fontWeight: "bold" }}>
                Login
              </Link>
            </li>
          </ul>
          
          <button 
            className="btn  btn-sm"
            onClick={toggleMute}
          >
            {isMuted ? "🔇 " : "🔊 "}
          </button>
        </>
      );
    }
  };

  return (
    <>
      {/* Hidden audio element */}
      <audio ref={audioRef} loop>
        <source src="C:\Users\Andre\Desktop\DocumentAccessTracker-main(2)\DocumentAccessTracker-main\AdamLibrary\Adam\client\public\images\library.mp3" type="audio/mpeg" />
      </audio>
      
      <nav className="navbar navbar-expand-lg" style={{ backgroundColor: '#964B00' }}>
        <div className="container-fluid" style={{ backgroundColor: '#964B00', fontWeight: "bold" }}>
          <a className="navbar-brand" style={{ color: 'rgb(255, 236, 223)' }}>
            Library
            <img src="/images/logo.png" alt="" width="50px" />
          </a>
          <button 
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            {renderNavbarContent()}
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;