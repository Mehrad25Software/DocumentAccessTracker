import "../pages/css/styles.css";



const Footer = (props) => {
  
  return (
    <footer
   
    >
      <p>This website was created May 2025</p>
    </footer>
  );

  
};


export default Footer;
