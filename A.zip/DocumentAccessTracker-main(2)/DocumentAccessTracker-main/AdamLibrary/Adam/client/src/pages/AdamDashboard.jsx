import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./css/Dashboard.css";

const AdamDashboard = ({ isAuthenticated }) => {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      alert("You must be logged in to access this page");
      navigate("/Login");
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="dashboard-container">
      <h1>Welcome to Adam's Dashboard</h1>
      <p>This is your personal library management area.</p>
      
      {/* Add your dashboard content here */}
      <div className="dashboard-content">
        {/* Your dashboard components go here */}
      </div>
    </div>
  );
};

export default AdamDashboard;