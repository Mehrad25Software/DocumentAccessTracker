import "./css/styles.css";
import 'animate.css';
import React from "react";
import { Link } from "react-router-dom";

const folders = [
  "JFK Folder", "Free Folder", "Free Folder", "Free Folder",
  "Free Folder", "Free Folder", "Free Folder", "Free Folder",
  "Free Folder", "Free Folder", "Free Folder", "Free Folder",
  "Free Folder", "Free Folder", "Free Folder", "Free Folder", 
  "Free Folder", "Free Folder"
];

const Home = () => {
  return (
    <>
      <div className="body">
        <h1 className="animate__animated animate__rubberBand home">
          Welcome to The Library
        </h1>
        <img
          src="../images/library.webp"
          alt="Library"
          style={{ width: "100%", maxWidth: "800px", height: "auto",  marginBottom: "40px" }}
        />
        <br />
        {/* Folder Grid */}
        <div className="container">
          <div className="row justify-content-center">
            {folders.map((folderName, index) => (
              <div
                key={index}
                className="col-6 col-sm-4 col-md-3 col-lg-2 mb-4 d-flex justify-content-center"
              >
                <div style={{ width: "8rem" }}>
                  <Link to={`/folder/${encodeURIComponent(folderName)}`} className="folder-link text-decoration-none">
                    <img
                      className="card-img-top"
                      src="../images/folder.png"
                      alt="Folder"
                    />
                    <div className="card-body">
                      <p className="card-text" style={{ color: "black", textAlign: "center" }}>
                        {folderName}
                      </p>
                    </div>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;