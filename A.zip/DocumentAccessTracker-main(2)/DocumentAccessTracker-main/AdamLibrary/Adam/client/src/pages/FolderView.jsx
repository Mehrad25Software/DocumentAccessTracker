import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import "./css/styles.css";

// Hardcoded PDFs for each folder
const folderContents = {
  "JFK Folder": [
    { name: "JFK Speech 1961.pdf", url: "/pdfs/jfk-speech-1961.pdf", date: "2024-01-15", size: 2500000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Biography.pdf", url: "/pdfs/jfk-biography.pdf", date: "2024-03-20", size: 1800000 },
    { name: "JFK Letters.pdf", url: "/pdfs/jfk-letters.pdf", date: "2024-02-10", size: 3200000 }
  ],
  "Free Folder": [
    { name: "Sample Document.pdf", url: "/pdfs/sample.pdf", date: "2024-01-01", size: 1000000 }
  ]
};

const FolderView = () => {
  const { folderName } = useParams();
  const decodedFolderName = decodeURIComponent(folderName);
  
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOption, setSortOption] = useState("name");
  
  // Get PDFs for this folder, or empty array if none
  let pdfs = folderContents[decodedFolderName] || [];

  // Filter by search term
  if (searchTerm) {
    pdfs = pdfs.filter(pdf => 
      pdf.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  // Sort PDFs based on selected option
  const sortedPdfs = [...pdfs].sort((a, b) => {
    switch(sortOption) {
      case "newest":
        return new Date(b.date) - new Date(a.date);
      case "oldest":
        return new Date(a.date) - new Date(b.date);
      case "size-large":
        return b.size - a.size;
      case "size-small":
        return a.size - b.size;
      case "name":
      default:
        return a.name.localeCompare(b.name);
    }
  });

  // Format file size
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  // Download all PDFs function
  const downloadAllPDFs = async () => {
    // Sort by upload date (oldest first)
    const sortedByDate = [...pdfs].sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // Download each PDF with a small delay to avoid overwhelming the browser
    for (let i = 0; i < sortedByDate.length; i++) {
      const pdf = sortedByDate[i];
      
      // Create a temporary link and click it
      const link = document.createElement('a');
      link.href = pdf.url;
      link.download = pdf.name;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Add a small delay between downloads (500ms)
      if (i < sortedByDate.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    alert(`Downloading ${sortedByDate.length} PDFs in order of upload date...`);
  };

  return (
    <div className="body" style={{ justifyContent: "flex-start", paddingTop: "2rem" }}>
      <div className="container-fluid" style={{ textAlign: "left" }}>
        {/* Top controls row */}
        <div className="row align-items-center mb-4">
          {/* Back button - left side */}
          <div className="col-12 col-md-3 mb-2 mb-md-0">
            <Link to="/" className="btn btn-outline-light">
              ← Back to Library
            </Link>
          </div>
          
          {/* Search box - middle */}
          <div className="col-12 col-md-2 mb-2 mb-md-0">
            <input
              type="text"
              className="form-control"
              placeholder="Search for file..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ backgroundColor: "rgba(255, 255, 255, 0.9)" }}
            />
          </div>
          
          {/* Sort dropdown - right side */}
          <div className="col-12 col-md-2 mb-2 mb-md-0">
            <select 
              className="form-select"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              style={{ backgroundColor: "rgba(255, 255, 255, 0.9)" }}
            >
              <option value="name">Order by Name</option>
              <option value="newest">Most Recent</option>
              <option value="oldest">Oldest First</option>
              <option value="size-large">Largest First</option>
              <option value="size-small">Smallest First</option>
            </select>
          </div>
          
          {/* Download All button */}
          <div className="col-auto">
            <button 
              onClick={downloadAllPDFs}
              className="btn btn-success"
              disabled={pdfs.length === 0}
            >
              📥 Download All
            </button>
          </div>
        </div>

        <h1 className="home" style={{ color: "rgb(255, 254, 252)", marginBottom: "2rem" }}>
          {decodedFolderName}
        </h1>

        {sortedPdfs.length > 0 ? (
          <div className="row">
            {sortedPdfs.map((pdf, index) => (
              <div key={index} className="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                <div className="card glass-card">
                  <div className="card-body text-center">
                    <img 
                      src="../images/pdf-icon.png" 
                      alt="PDF" 
                      style={{ width: "80px", height: "80px", marginBottom: "1rem" }}
                      onError={(e) => {
                        e.target.style.display = 'none';
                      }}
                    />
                    <h5 className="card-title" style={{ fontSize: "0.9rem", minHeight: "40px" }}>
                      {pdf.name}
                    </h5>
                    <p className="card-text" style={{ fontSize: "0.8rem", color: "#666" }}>
                      {formatFileSize(pdf.size)}
                    </p>
                    <a 
                      href={pdf.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="btn btn-primary btn-sm" 
                      style={{backgroundColor: "#964B00", borderColor:"white"}}
                    >
                      Open PDF
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="alert alert-info" role="alert" style={{ backgroundColor: "rgba(255, 255, 255, 0.9)" }}>
            {searchTerm ? "No files found matching your search." : "This folder is empty. No documents available yet."}
          </div>
        )}
      </div>
    </div>
  );
};

export default FolderView;