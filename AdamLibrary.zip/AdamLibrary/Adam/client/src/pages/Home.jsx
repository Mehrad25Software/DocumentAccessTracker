import "./css/styles.css";
const Home = (props) => {
  return (
    <>
      <div class="body" className="body">
         <h1 className="home">Welcome to The Library </h1>
         <img
  src="../images/library.webp"
  alt="Library"
  style={{ width: "100%", maxWidth: "800px", height: "auto" }}
/>

        <br/>
    
        
      </div>
    </>
  );
};

export default Home;
